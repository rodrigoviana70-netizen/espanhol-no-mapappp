# Plano — ajuste de conversão do hero e CTA mobile

## Alterações
- Compactar somente os espaçamentos verticais do hero, aproximando avaliação, título, subtítulo, preço, benefícios, imagem e botão sem alterar conteúdo, cores, fontes ou imagens.
- Ajustar o tamanho máximo da imagem no hero conforme a tela para deixar a oferta principal mais visível acima da dobra.
- Adicionar um CTA fixo apenas no celular com o texto “QUERO MEU ACESSO AGORA”, apontando para `#planos`.
- Exibir o CTA flutuante depois que o visitante avançar além do topo e ocultá-lo ao chegar à seção de preços ou ao abrir a oferta, evitando cobrir conteúdo importante.
- Respeitar a área segura inferior do celular, manter boa área de toque e preservar o estilo amarelo atual.

## Validação
- Conferir hero e CTA em celular e computador.
- Confirmar que o CTA aparece somente no celular, leva aos preços e não encobre a seção de oferta.
- Verificar que checkouts, UTMs, Pixel, textos e demais seções permanecem intactos.
