# Plano — ajustes de carrosséis e Meta Pixel

## Alterações
- Exibir cada prova social em um recorte quadrado, ocultando número e foto de perfil do WhatsApp.
- Usar as novas fotos em “Veja como é o material por dentro” e transformar essa área em carrossel.
- Fazer os dois carrosséis avançarem automaticamente, mantendo arraste manual e acessibilidade.
- Atualizar todas as menções visíveis de “+240 mapas” para “+300 mapas”.
- Inserir exatamente um Meta Pixel global, com o ID fornecido, no final do cabeçalho de todas as páginas.

## Validação
- Conferir computador e celular, movimento dos carrosséis, recortes das imagens e ausência de erros.
- Preservar preços, links de pagamento, rastreamento já existente e todo o conteúdo não solicitado.
