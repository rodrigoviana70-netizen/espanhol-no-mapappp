# Plano — carrosséis e desempenho mobile

## Alterações
- Manter somente as 9 provas sociais novas, que possuem foto, removendo as antigas sem foto.
- Fazer os carrosséis de materiais e feedbacks avançarem automaticamente em sentidos opostos, com arraste por toque e pausa durante a interação.
- Carregar sob demanda as imagens fora da primeira tela e limitar o carregamento antecipado nos carrosséis.
- Criar versões menores e mais leves das imagens para celular e telas maiores, preservando proporções e aparência.
- Reservar o espaço de imagens e seções para evitar mudanças bruscas durante o carregamento.
- Reduzir trabalho visual e animações não essenciais, especialmente em celulares e para quem prefere menos movimento.
- Revisar código e dependências não usados sem alterar conteúdo, links ou comportamento comercial.
- Preservar integralmente Meta Pixel, UTMify, checkout e demais rastreamentos existentes.

## Validação
- Conferir visual e arraste em celular e computador.
- Confirmar sentidos opostos, pausa ao tocar e retomada automática.
- Verificar carregamento de imagens, estabilidade visual, links de checkout e rastreamentos.
- Confirmar que a página finaliza sem erros.
