# Plano — Espanhol no Mapa

## Objetivo
Criar uma página de vendas completa, responsiva e focada em conversão para o produto **Espanhol no Mapa**, preservando a estrutura e a linguagem visual solicitadas: alternância entre áreas claras e azul-marinho, amarelo nos CTAs, cards brancos, forte hierarquia e aparência educacional premium.

## Estrutura da página
- Header simples com marca e botão que leva aos planos.
- Hero com oferta principal, benefícios, mockup visual do produto e CTA.
- Galeria horizontal e arrastável com exemplos de mapas mentais.
- Carrossel de prova social com avaliações e formatos variados.
- Currículo interativo por níveis A1–C2.
- Três perfis de público.
- Área escura com seis bônus.
- Comparativo de planos, com destaque forte para o Completo.
- Garantia, passos de acesso, FAQ interativo e CTA final.
- Footer minimalista.
- Popup de upgrade exibido somente ao escolher o plano Essencial.

## Interações
- Rolagem suave de todos os CTAs gerais até os planos.
- Tabs funcionais para os níveis A1–C2.
- Galerias horizontais fluidas e arrastáveis no celular.
- FAQ em accordion com abertura suave.
- Popup responsivo com fechar, recusar e aceitar a oferta.
- Animações discretas de entrada e movimento, respeitando preferência por movimento reduzido.

## Imagens e conteúdo visual
- Criar inicialmente mockups e mapas mentais estilizados para a página já funcionar sem espaços vazios.
- Preparar hero e depoimentos para substituição direta pelas imagens reais que serão enviadas depois.
- Usar carregamento adiado nas imagens fora da primeira tela.

## Implementação
- Organizar cada seção em componente reutilizável.
- Centralizar as três URLs de checkout em constantes editáveis, sem inventar links.
- Usar tokens semânticos para toda a paleta, tipografia, sombras e raios.
- Garantir navegação por teclado, foco visível, textos alternativos e controles acessíveis.
- Adicionar título, descrição, Open Graph, Twitter Card e dados estruturados adequados.
- Validar visualmente em desktop e celular, além de conferir erros de execução e compilação.

## Observação
Os botões dos planos permanecerão preparados, mas sem redirecionamento externo até que as URLs reais de checkout sejam fornecidas.
