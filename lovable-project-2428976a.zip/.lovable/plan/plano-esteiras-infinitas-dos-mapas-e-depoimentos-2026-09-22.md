# Plano — esteiras infinitas dos mapas e depoimentos

## Alterações
- Substituir somente o mecanismo atual dos dois carrosséis por um componente reutilizável de marquee contínuo com `requestAnimationFrame`.
- Renderizar grupos idênticos consecutivos, medindo a largura real do primeiro grupo e preservando a posição ao completar cada ciclo.
- Usar velocidade constante de 32 px/s no computador e 25 px/s no celular para os mapas; 22 px/s e 18 px/s para os depoimentos.
- Remover setas, indicadores, paginação, scroll-snap e rolagem horizontal visível dos dois carrosséis.
- Manter exatamente os arrays, imagens, textos e botões atuais; aplicar dimensões menores, espaçamento uniforme, sombra discreta e fade lateral sutil.
- Pausar os mapas apenas com mouse no computador, retomar da mesma posição, pausar fora da tela e respeitar redução de movimento.
- Recalcular a largura com `ResizeObserver` sem reiniciar a esteira; preservar carregamento progressivo e proporção das imagens.

## Validação
- Conferir 1920px, 1366px, 768px e 390px, incluindo redimensionamento.
- Observar o movimento por pelo menos dois minutos e confirmar velocidade linear, emenda invisível e ausência de espaços vazios.
- Confirmar aproximadamente 5–7 mapas visíveis no desktop e 1,7–2,2 no celular.
- Confirmar ausência de rolagem lateral e preservação integral de imagens, CTAs, links e rastreamentos.
