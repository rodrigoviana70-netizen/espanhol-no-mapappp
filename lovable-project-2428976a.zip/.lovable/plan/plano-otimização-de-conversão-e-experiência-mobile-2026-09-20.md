# Plano — otimização de conversão e experiência mobile

## Hero
- Simplificar a primeira dobra para uma única imagem principal, selo, título, subtítulo e os três benefícios solicitados.
- Levar o CTA principal diretamente ao checkout do plano completo de R$ 19,90, preservando UTMs e demais parâmetros de rastreamento.
- Compactar os espaçamentos no celular e manter a imagem AVIF prioritária, com dimensões reservadas para evitar mudanças no carregamento.

## Carrosséis
- Ajustar o carrossel do material para exibir de 3 a 5 imagens no desktop e uma imagem com parte da próxima no celular.
- Ajustar os feedbacks para cerca de três cards no desktop e um com parte do próximo no celular, preservando todos os depoimentos existentes.
- Adicionar arraste por toque e mouse, setas discretas, indicadores de posição, autoplay nos intervalos pedidos, pausa durante interação e retomada automática.
- Implementar loop visual contínuo sem biblioteca pesada e manter carregamento gradual das imagens abaixo da primeira dobra.

## Oferta e CTA mobile
- Deixar a comparação dos planos mais clara, mantendo preços, conteúdo e links atuais.
- Destacar o plano completo de R$ 19,90 com o selo “MAIS ESCOLHIDO” e CTA “QUERO ACESSO AGORA”, sem enfraquecer o plano Essencial.
- Atualizar o botão fixo no celular para “QUERO ACESSO — R$19,90”, apontando diretamente ao checkout principal com rastreamento.
- Exibir o botão após a primeira dobra, ocultá-lo próximo de CTAs importantes e respeitar a área segura do iPhone.

## Desempenho e acabamento
- Manter as imagens otimizadas em AVIF, prioridade somente no topo e carregamento adiado no restante da página.
- Reduzir trabalho simultâneo dos carrosséis e preservar espaço de imagens, cards e seções para estabilidade visual.
- Aplicar apenas transições leves, respeitar redução de movimento e revisar larguras, margens e textos no celular para impedir rolagem lateral.
- Preservar integralmente Meta Pixel, UTMify, scripts, checkout e passagem de parâmetros existentes.

## Validação
- Conferir visual e interação em celular e desktop, incluindo toque, arraste por mouse, setas, indicadores, autoplay, pausa, retomada e loop.
- Verificar carregamento gradual das imagens, estabilidade visual, ausência de rolagem horizontal e links dos três fluxos de compra.
- Confirmar Meta Pixel, UTMify, parâmetros de campanha e finalização sem erros.
