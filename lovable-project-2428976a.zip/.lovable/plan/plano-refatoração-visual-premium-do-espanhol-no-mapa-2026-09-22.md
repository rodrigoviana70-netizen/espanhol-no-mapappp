# Plano — refatoração visual premium do Espanhol no Mapa

## Direção visual
- Refatorar a página existente, sem recriar sua estrutura comercial, usando preto/carvão, amarelo intenso, branco e off-white.
- Usar as referências enviadas em 18/09 para orientar contraste, ritmo entre seções, cards, botões, sombras e acabamento.
- Manter todas as imagens atuais do produto, mapas e depoimentos, além dos textos, bônus, preços e garantia já cadastrados.

## Topo e conversão
- Adicionar uma barra amarela fixa com a data atual no formato brasileiro, conforme confirmado, centralizada em uma configuração simples e preparada para futura fonte externa.
- Simplificar o cabeçalho e reorganizar o hero existente com selo, texto, imagem prioritária, benefícios e CTA amarelo.
- Manter todos os botões externos, ações, parâmetros e URLs atuais; os demais CTAs continuam levando aos cards da oferta, conforme ajuste anterior.

## Seções e conteúdo
- Alternar fundos claros e escuros para criar ritmo e hierarquia.
- Redesenhar materiais e depoimentos em carrosséis leves, contínuos, arrastáveis e com pausa durante interação.
- Atualizar visualmente conteúdo por níveis, público, bônus, planos, garantia, entrega, FAQ e CTA final sem alterar seus dados comerciais.
- Adicionar o CNPJ informado ao rodapé de forma visível e discreta.
- Não exibir notificações de compra até existir uma fonte de eventos reais; não criar compradores fictícios.

## Movimento e desempenho
- Implementar revelações suaves com IntersectionObserver, pausando movimentos para quem prefere redução de movimento.
- Preservar AVIF/WebP existentes, prioridade do hero, dimensões reservadas e carregamento adiado abaixo da primeira tela.
- Não instalar bibliotecas de carrossel ou animação.

## Validação
- Conferir celular e computador, ausência de rolagem lateral, legibilidade, swipe, autoplay, pausa, barra superior e CTA móvel.
- Verificar links, UTMs, Meta Pixel, scripts, eventos, preços, bônus, garantia, imagens e CNPJ.
- Confirmar que notificações de compra continuam ocultas sem eventos reais e que a página finaliza sem erros.
