import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  ArrowRight,
  BookOpen,
  Brain,
  Check,
  CheckCircle2,
  ChevronDown,
  ClipboardCheck,
  Download,
  GraduationCap,
  Laptop,
  ShieldCheck,
  Sparkles,
  X,
} from "lucide-react";
import heroProductAsset from "@/assets/hero-guia.webp";
import heroProductMobileAsset from "@/assets/hero-guia-720.avif";
import heroProductDesktopAsset from "@/assets/hero-guia-1200.avif";
import testimonial1 from "@/assets/depoimentos/depoimento-1.webp";
import testimonial2 from "@/assets/depoimentos/depoimento-2.webp";
import testimonial3 from "@/assets/depoimentos/depoimento-3.webp";
import testimonial4 from "@/assets/depoimentos/depoimento-4.webp";
import testimonial5 from "@/assets/depoimentos/depoimento-5.webp";
import testimonial6 from "@/assets/depoimentos/depoimento-6.webp";
import testimonial7 from "@/assets/depoimentos/depoimento-7.webp";
import testimonial8 from "@/assets/depoimentos/depoimento-8.webp";
import testimonial9 from "@/assets/depoimentos/depoimento-9.webp";
import testimonial10 from "@/assets/depoimentos/depoimento-10.webp";
import materialAlphabet from "@/assets/mapa-alfabeto-pronunciacao-900.avif";
import materialCountries from "@/assets/mapa-paises-nacionalidades-900.avif";
import materialSubjunctive from "@/assets/mapa-subjuntivo-900.avif";
import materialNegation from "@/assets/mapa-negacao-correcao-900.avif";
import materialPronouns from "@/assets/mapa-pronomes-perspectiva-900.avif";
import materialImplicit from "@/assets/mapa-informacao-implicita-900.avif";
import materialComplaints from "@/assets/mapa-queixas-reclamacoes-900.avif";
import materialExperiences from "@/assets/mapa-narrar-experiencias-900.avif";
import materialSummary from "@/assets/mapa-resumir-sintetizar-900.avif";
import bonusExercicios from "@/assets/bonus-covers/bonus-50-exercicios.avif";
import bonusTrabalho from "@/assets/bonus-covers/bonus-espanhol-trabalho.avif";
import bonusExpressoes from "@/assets/bonus-covers/bonus-100-expressoes.avif";
import bonusFrases from "@/assets/bonus-covers/bonus-200-frases.avif";
import bonusViagem from "@/assets/bonus-covers/bonus-espanhol-viajar.avif";
import bonusPronuncia from "@/assets/bonus-covers/bonus-guia-pronuncia.avif";
import planoCompletoCover from "@/assets/plan-covers/plano-completo.avif";
import planoEssencialCover from "@/assets/plan-covers/plano-essencial.avif";
import aluno1 from "@/assets/alunos/aluno-1.webp";
import aluno2 from "@/assets/alunos/aluno-2.webp";
import aluno3 from "@/assets/alunos/aluno-3.webp";
import aluno4 from "@/assets/alunos/aluno-4.webp";
import aluno5 from "@/assets/alunos/aluno-5.webp";
import aluno6 from "@/assets/alunos/aluno-6.webp";

export const ESSENCIAL_CHECKOUT_URL = "https://pay.cakto.com.br/qc3r48a";
export const COMPLETO_CHECKOUT_URL = "https://pay.cakto.com.br/3fnwwoy";
export const UPSELL_CHECKOUT_URL = "https://pay.cakto.com.br/59hcikj";

// Repassa os parâmetros de rastreamento (utm_*, fbclid, gclid...) da página para o checkout.
export function withTracking(url: string) {
  if (typeof window === "undefined" || !url) return url;
  try {
    const incoming = new URLSearchParams(window.location.search);
    const target = new URL(url);
    incoming.forEach((value, key) => {
      if (!value) return;
      if (/^utm_/i.test(key) || ["fbclid", "gclid", "ttclid", "src", "sck", "ref"].includes(key.toLowerCase())) {
        target.searchParams.set(key, value);
      }
    });
    return target.toString();
  } catch {
    return url;
  }
}


const noticeNames = ["Juliana L.", "Carlos M.", "Fernanda R.", "Mariana S.", "Rafael A.", "Beatriz C."];

const testimonials = [testimonial1, testimonial2, testimonial3, testimonial4, testimonial5, testimonial6, testimonial7, testimonial8, testimonial9, testimonial10];

const materialPhotos = [
  { asset: materialAlphabet, alt: "Mapa mental sobre alfabeto e pronúncia em espanhol" },
  { asset: materialCountries, alt: "Mapa mental sobre países e nacionalidades em espanhol" },
  { asset: materialSubjunctive, alt: "Mapa mental sobre subjuntivo sem verbo principal" },
  { asset: materialNegation, alt: "Mapa mental sobre negação e correção em espanhol" },
  { asset: materialPronouns, alt: "Mapa mental sobre pronomes e perspectiva em espanhol" },
  { asset: materialImplicit, alt: "Mapa mental sobre informações implícitas em espanhol" },
  { asset: materialComplaints, alt: "Mapa mental sobre queixas e reclamações em espanhol" },
  { asset: materialExperiences, alt: "Mapa mental sobre como narrar experiências em espanhol" },
  { asset: materialSummary, alt: "Mapa mental sobre como resumir e sintetizar em espanhol" },
];

const bonuses = [
  { image: bonusExercicios, title: "50 exercícios", text: "50 exercícios práticos para revisar e fixar vocabulário, frases e estruturas essenciais do espanhol." },
  { image: bonusTrabalho, title: "Espanhol para o trabalho", text: "Frases, vocabulário e expressões para se comunicar com mais confiança em reuniões, entrevistas, e-mails, atendimento e situações profissionais." },
  { image: bonusViagem, title: "Espanhol para viajar", text: "Frases e vocabulário para aeroporto, hotel, restaurante, transporte, compras e situações comuns durante uma viagem." },
  { image: bonusPronuncia, title: "Guia de pronúncia do espanhol", text: "Guia visual e prático para entender os principais sons do espanhol e melhorar a pronúncia." },
  { image: bonusExpressoes, title: "100 expressões essenciais", text: "100 expressões úteis para situações reais, conversação e comunicação no dia a dia." },
  { image: bonusFrases, title: "200 frases para conversação", text: "200 frases práticas para desenvolver conversação e responder com mais naturalidade em espanhol." },
];

const faqs = [
  ["O material é indicado para iniciantes?", "Sim. O conteúdo começa no nível A1, com os fundamentos, e avança em uma sequência clara e progressiva."],
  ["Preciso saber espanhol antes de começar?", "Não. Você pode começar do zero e seguir os mapas na ordem sugerida."],
  ["O conteúdo vai do básico ao avançado?", "Sim. O Plano Completo reúne conteúdos dos níveis A1 ao C2, dos fundamentos às estruturas avançadas."],
  ["Como recebo o material?", "Após a confirmação da compra, você recebe as instruções de acesso digital pela plataforma."],
  ["Posso acessar pelo celular?", "Sim. O material pode ser estudado no celular, tablet ou computador."],
  ["O acesso expira?", "Não. O acesso é vitalício e você pode voltar ao material sempre que precisar."],
  ["Posso imprimir os mapas?", "Sim. Os arquivos foram organizados para estudo digital e também podem ser impressos para uso pessoal."],
  ["Existem exercícios?", "Sim. O Plano Completo inclui bônus com exercícios práticos e expressões essenciais para treinar."],
  ["O pagamento é único?", "Sim. Não há mensalidade ou cobrança recorrente."],
  ["Como funciona a garantia?", "Você tem 7 dias para conhecer o material e pode solicitar reembolso nesse período conforme as condições da plataforma."],
];

function Container({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto w-full max-w-7xl px-5 sm:px-8 lg:px-12 ${className}`}>{children}</div>;
}

function Logo({ inverse = false }: { inverse?: boolean }) {
  return <a href="#inicio" className={`font-display text-lg font-extrabold uppercase tracking-normal ${inverse ? "text-primary-foreground" : "text-primary"}`}>Espanhol no <span className="text-accent-strong">Mapa</span></a>;
}

function formatCurrentOfferDate() {
  return new Intl.DateTimeFormat("pt-BR", {
    timeZone: "America/Sao_Paulo",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  }).format(new Date());
}

function OfferBar() {
  const [date, setDate] = useState(formatCurrentOfferDate);
  useEffect(() => {
    const update = () => setDate(formatCurrentOfferDate());
    update();
    const timer = window.setInterval(update, 60000);
    return () => window.clearInterval(timer);
  }, []);
  return <div className="offer-bar" role="status"><span aria-hidden="true">⚠️</span><span suppressHydrationWarning>Essa oferta vai se encerrar no dia {date}</span></div>;
}

function PrimaryCTA({ children, href = "#planos", dark = false, onClick, className = "" }: { children: ReactNode; href?: string; dark?: boolean; onClick?: () => void; className?: string }) {
  const classes = `cta-button ${dark ? "cta-dark" : "cta-yellow"} ${className}`;
  if (onClick) return <button type="button" onClick={onClick} className={classes}>{children}<ArrowRight className="h-5 w-5 shrink-0" /></button>;
  return <a href={href} className={classes}>{children}<ArrowRight className="h-5 w-5 shrink-0" /></a>;
}

function SectionHeading({ eyebrow, title, subtitle, inverse = false }: { eyebrow?: string; title: string; subtitle?: string; inverse?: boolean }) {
  return <div className="mx-auto mb-10 max-w-3xl text-center sm:mb-14">
    {eyebrow && <p className={`mb-3 text-xs font-extrabold uppercase tracking-widest ${inverse ? "text-accent-strong" : "text-primary"}`}>{eyebrow}</p>}
    <h2 className={`font-display text-3xl font-extrabold leading-tight sm:text-4xl lg:text-5xl ${inverse ? "text-primary-foreground" : "text-primary"}`}>{title}</h2>
    {subtitle && <p className={`mx-auto mt-4 max-w-2xl text-base leading-relaxed sm:text-lg ${inverse ? "text-on-dark-muted" : "text-muted-foreground"}`}>{subtitle}</p>}
  </div>;
}

function InfiniteMarquee({
  items,
  label,
  desktopSpeed,
  mobileSpeed,
  itemClassName,
  renderItem,
}: {
  items: readonly unknown[];
  label: string;
  desktopSpeed: number;
  mobileSpeed: number;
  itemClassName: string;
  renderItem: (item: unknown, index: number, duplicate: boolean) => ReactNode;
}) {
  const viewportRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const groupRef = useRef<HTMLDivElement>(null);
  const offsetRef = useRef(0);
  const groupWidthRef = useRef(0);
  const pausedRef = useRef(false);

  useEffect(() => {
    const viewport = viewportRef.current;
    const track = trackRef.current;
    const group = groupRef.current;
    if (!viewport || !track || !group) return;

    const mobile = window.matchMedia("(max-width: 767px)");
    let frame = 0;
    let previousTime = performance.now();

    const measure = () => {
      const nextWidth = group.scrollWidth;
      if (!nextWidth) return;
      groupWidthRef.current = nextWidth;
      offsetRef.current %= nextWidth;
      track.style.transform = `translate3d(${-offsetRef.current}px, 0, 0)`;
    };

    const resizeObserver = new ResizeObserver(measure);
    resizeObserver.observe(group);
    measure();

    const animate = (time: number) => {
      const deltaSeconds = Math.min((time - previousTime) / 1000, 0.05);
      previousTime = time;
      const width = groupWidthRef.current;
      if (width && !pausedRef.current) {
        const speed = mobile.matches ? mobileSpeed : desktopSpeed;
        offsetRef.current += speed * deltaSeconds;
        if (offsetRef.current >= width) offsetRef.current -= width;
        track.style.transform = `translate3d(${-offsetRef.current}px, 0, 0)`;
      }
      frame = window.requestAnimationFrame(animate);
    };
    frame = window.requestAnimationFrame(animate);

    return () => {
      window.cancelAnimationFrame(frame);
      resizeObserver.disconnect();
    };
  }, [desktopSpeed, mobileSpeed]);

  const renderGroup = (duplicate: boolean) => items.map((item, index) => (
    <div key={`${duplicate ? "copy" : "original"}-${index}`} className={itemClassName}>
      {renderItem(item, index, duplicate)}
    </div>
  ));

  return <div
    ref={viewportRef}
    className="marquee-viewport"
    role="region"
    aria-label={label}
    onMouseEnter={() => { if (window.matchMedia("(hover: hover) and (pointer: fine)").matches) pausedRef.current = true; }}
    onMouseLeave={() => { pausedRef.current = false; }}
  >
    <div ref={trackRef} className="marquee-track">
      <div ref={groupRef} className="marquee-group">{renderGroup(false)}</div>
      <div className="marquee-group" aria-hidden="true">{renderGroup(true)}</div>
    </div>
  </div>;
}


export function Hero() {
  return <section id="inicio" className="hero-section overflow-hidden pb-9 pt-6 sm:pb-12 sm:pt-8">
    <Container>
      <div className="mx-auto max-w-4xl text-center">
        <div className="hero-badge" aria-label="Avaliação de cinco estrelas por mais de mil setecentos e oitenta e seis alunos"><span className="text-accent-strong">★★★★★</span><span className="hero-badge-divider" />+1.786 alunos</div>
        <h1 className="mt-3 font-display text-4xl font-black leading-[1.05] text-primary-foreground sm:mt-4 sm:text-5xl lg:text-6xl"><span className="marker-highlight">+300 Mapas Mentais</span><br /> para Aprender e Revisar Espanhol</h1>
        <p className="mx-auto mt-3 max-w-2xl text-base leading-relaxed text-on-dark-muted sm:text-lg">Aprenda espanhol de forma visual, organizada e prática — do básico ao avançado.</p>
        <p className="mt-2 text-lg font-black text-accent-strong sm:text-xl">A partir de R$ 9,90</p>
        <div className="mx-auto mt-3 flex max-w-3xl flex-wrap justify-center gap-x-5 gap-y-1.5 text-xs font-extrabold text-primary-foreground sm:text-sm">{["Área de membros exclusiva", "Acesso imediato", "Do A1 ao C2", "Material imprimível", "6 bônus inclusos"].map((item) => <span key={item} className="flex items-center gap-1.5"><Check className="h-4 w-4 text-success" />{item}</span>)}</div>
      </div>
      <div className="hero-product relative mx-auto mt-5 max-w-3xl sm:mt-6">
        <picture><source media="(max-width: 767px)" srcSet={heroProductMobileAsset} type="image/avif" /><source srcSet={heroProductDesktopAsset} type="image/avif" /><img src={heroProductAsset} alt="Kit Espanhol no Mapa — +300 mapas mentais em espanhol com 6 bônus inclusos" width={1200} height={904} fetchPriority="high" decoding="async" className="relative aspect-[4/3] w-full rounded-lg object-cover shadow-product" /></picture>
      </div>
      <div className="mt-4 flex flex-col items-center sm:mt-5"><a href="#planos" data-primary-cta className="cta-button cta-yellow">Quero meu acesso agora <ArrowRight className="h-5 w-5 shrink-0" /></a><p className="mt-2 text-sm text-on-dark-muted">Acesso imediato após a confirmação do pagamento.</p><div className="mt-4 flex flex-col items-center gap-2 text-center" aria-label="Mais de 1.786 alunos"><div className="flex -space-x-3">{studentAvatars.map((avatar, i) => <img key={avatar} src={avatar} alt={`Aluno ${i + 1} do Espanhol no Mapa`} width={56} height={56} loading="lazy" decoding="async" className="h-10 w-10 rounded-full border-2 border-primary object-cover sm:h-12 sm:w-12" />)}</div><p className="font-display text-base font-black uppercase tracking-wide text-primary-foreground sm:text-lg">Mais de 1.786 alunos!</p><p className="flex items-center gap-1.5 text-xs font-semibold text-on-dark-muted"><ShieldCheck className="h-4 w-4 text-success-bright" /> Compra 100% segura • 7 dias de garantia</p></div></div>
    </Container>
  </section>;
}

export function ProductPreview() {
  return <section className="section-dark py-20 sm:py-28">
    <Container><SectionHeading inverse eyebrow="Por dentro do material" title="Veja como é o material por dentro" subtitle="Mapas mentais visuais para estudar e revisar de forma muito mais organizada." /></Container>
    <InfiniteMarquee
      items={materialPhotos}
      label="Esteira contínua de imagens do material"
      desktopSpeed={32}
      mobileSpeed={25}
      itemClassName="material-marquee-item"
      renderItem={(item, index, duplicate) => {
        const material = item as (typeof materialPhotos)[number];
        return <img src={material.asset} alt={duplicate ? "" : material.alt} width={900} height={600} loading={!duplicate && index < 7 ? "eager" : "lazy"} decoding="async" fetchPriority="low" className="material-preview-image" />;
      }}
    />
    <div className="mt-8 flex justify-center px-5"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div>
  </section>;
}

export function Testimonials() {
  return <section className="bg-off-white py-16 sm:py-20">
    <Container><SectionHeading eyebrow="Alunos do Espanhol no Mapa" title="Veja o que os alunos dizem" subtitle="Feedbacks de quem já começou a estudar com o material." /></Container>
    <InfiniteMarquee
      items={testimonials}
      label="Esteira contínua de feedbacks de alunos"
      desktopSpeed={22}
      mobileSpeed={18}
      itemClassName="testimonial-marquee-item"
      renderItem={(item, index, duplicate) => <figure className="testimonial-image-card">
        <div className="testimonial-square"><img src={item as string} alt={duplicate ? "" : `Feedback ${index + 1} de aluno do Espanhol no Mapa via WhatsApp`} width={480} height={853} loading={!duplicate && index < 7 ? "eager" : "lazy"} decoding="async" fetchPriority="low" /></div>
        <figcaption className="border-t border-border bg-card px-4 py-3"><p className="text-sm font-extrabold text-primary">Feedback - Aluno do Kit</p><p className="mt-0.5 text-xs text-muted-foreground">Feedback via WhatsApp</p></figcaption>
      </figure>}
    />
    <div className="mt-8 flex justify-center px-5"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div>
  </section>;
}


export function Audience() {
  const cards = [
    { icon: BookOpen, title: "Para quem está começando do zero", text: "Aprenda espanhol seguindo uma ordem lógica e simples, sem ficar perdido entre centenas de conteúdos." },
    { icon: Brain, title: "Para quem estuda e esquece", text: "Use os mapas mentais para revisar rapidamente os assuntos e reforçar o conteúdo." },
    { icon: ClipboardCheck, title: "Para quem quer estudar de forma organizada", text: "Tenha os principais conteúdos de espanhol reunidos em um único lugar." },
  ];
  return <section className="bg-off-white py-20 sm:py-28"><Container><SectionHeading title="Para quem foi feito este material?" />
    <div className="grid gap-5 md:grid-cols-3">{cards.map(({ icon: Icon, title, text }) => <article key={title} className="feature-card"><div className="icon-box"><Icon className="h-7 w-7" /></div><h3 className="mt-6 font-display text-xl font-extrabold text-primary">{title}</h3><p className="mt-3 leading-relaxed text-muted-foreground">{text}</p></article>)}</div>
    <div className="mt-10 flex justify-center"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div>
  </Container></section>;
}

export function Bonuses() {
  return <section className="section-dark py-20 sm:py-28"><Container><SectionHeading inverse eyebrow="Bônus exclusivos" title="Você também recebe bônus especiais" subtitle="Materiais extras incluídos gratuitamente na oferta atual." />
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">{bonuses.map(({ image, title, text }, i) => <article key={title} className="bonus-card"><img src={image} alt={`Capa do bônus ${title}`} width={720} height={720} loading="lazy" decoding="async" className="bonus-cover" /><div className="bonus-content"><span className="bonus-badge">Bônus {i + 1}</span><h3 className="mt-5 font-display text-lg font-extrabold uppercase text-primary-foreground">{title}</h3><p className="mt-3 text-sm leading-relaxed text-on-dark-muted">{text}</p><div className="bonus-price"><span>R$ 58,90</span><span className="bonus-included"><Check className="h-3.5 w-3.5" /> Grátis</span></div></div></article>)}</div>
    <div className="mt-12 flex justify-center"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div>
  </Container></section>;
}

function CheckItem({ children }: { children: ReactNode }) {
  return <li className="flex items-start gap-2.5 text-sm text-foreground"><span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full bg-success-soft"><Check className="h-3.5 w-3.5 text-success" /></span>{children}</li>;
}

export function Pricing({ onEssential }: { onEssential: () => void }) {
  const openCheckout = (url: string) => { if (url) window.location.href = withTracking(url); };
  return <section id="planos" data-sticky-suppress className="bg-off-white py-20 sm:py-28"><Container><SectionHeading eyebrow="Pagamento único" title="Escolha o plano ideal para você" subtitle="Compare as opções e escolha o conteúdo que combina com seu momento." />
    <div className="mx-auto grid max-w-4xl items-stretch gap-6 lg:grid-cols-2">
      <article className="pricing-card"><div><img src={planoEssencialCover} alt="Kit Espanhol no Mapa Essencial" width={720} height={360} loading="lazy" decoding="async" fetchPriority="low" className="mb-5 aspect-[16/8] w-full rounded-md object-cover" /><p className="text-xs font-extrabold uppercase tracking-widest text-muted-foreground">Plano Essencial</p><h3 className="mt-3 font-display text-2xl font-black text-primary">Espanhol no Mapa<br />Essencial</h3><div className="mt-5 text-sm font-bold text-price-old line-through">De R$ 49,90</div><div className="flex items-end gap-1 text-primary"><span className="mb-2 text-lg font-bold">R$</span><span className="font-display text-6xl font-black">9</span><span className="mb-2 text-2xl font-black">,90</span></div><ul className="mt-6 space-y-3"><CheckItem>Mapas essenciais</CheckItem><CheckItem>Conteúdos básicos</CheckItem><CheckItem>Área de membros exclusiva</CheckItem><CheckItem>Acesso imediato</CheckItem><CheckItem>Acesso vitalício</CheckItem></ul></div><button type="button" onClick={onEssential} className="pricing-outline">Quero meu acesso agora</button></article>
      <article className="pricing-card pricing-featured"><div className="featured-ribbon">Oferta mais escolhida</div><div><img src={planoCompletoCover} alt="Kit Espanhol no Mapa Completo" width={720} height={360} loading="lazy" decoding="async" fetchPriority="low" className="mb-5 aspect-[16/8] w-full rounded-md object-cover" /><h3 className="font-display text-2xl font-black text-primary">Espanhol no Mapa<br />Completo</h3><p className="mt-2 text-sm font-semibold text-primary">A oferta recomendada: conteúdo completo + todos os bônus.</p><div className="mt-5 text-sm font-bold text-price-old line-through">De R$ 94,90</div><div className="flex items-end gap-1 text-primary"><span className="mb-2 text-lg font-bold">R$</span><span className="font-display text-6xl font-black">19</span><span className="mb-2 text-2xl font-black">,90</span></div><p className="mt-1 text-xs font-semibold text-muted-foreground">Pagamento único • acesso vitalício</p><ul className="mt-6 space-y-3"><CheckItem>+300 mapas mentais</CheckItem><CheckItem>Do A1 ao C2</CheckItem><CheckItem>Todos os conteúdos</CheckItem><CheckItem>Área de membros exclusiva</CheckItem><CheckItem>6 bônus especiais</CheckItem><CheckItem>Atualizações futuras</CheckItem><CheckItem>Acesso vitalício e imediato</CheckItem></ul></div><button type="button" onClick={() => openCheckout(COMPLETO_CHECKOUT_URL)} className="pricing-solid">Quero meu acesso agora <ArrowRight className="h-5 w-5" /></button></article>
    </div>
  </Container></section>;
}

export function Guarantee() {
  return <section className="bg-background py-20 sm:py-24"><Container><div className="mx-auto grid max-w-4xl items-center gap-8 md:grid-cols-[auto_1fr] md:gap-12"><div className="mx-auto grid h-36 w-36 place-items-center rounded-full border-8 border-accent-soft bg-background text-primary shadow-soft"><ShieldCheck className="h-20 w-20" /></div><div className="text-center md:text-left"><p className="mb-2 text-xs font-extrabold uppercase tracking-widest text-success">Sua compra protegida</p><h2 className="font-display text-3xl font-extrabold text-primary sm:text-4xl">Garantia incondicional de 7 dias</h2><p className="mt-4 leading-relaxed text-muted-foreground">Você terá 7 dias completos para conhecer o material. Se dentro desse período perceber que o Espanhol no Mapa não é para você, poderá solicitar o reembolso conforme as condições da plataforma. Sem complicação.</p><div className="mt-7 flex justify-center md:justify-start"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div></div></div></Container></section>;
}

export function AccessSteps() {
  const steps = [{ icon: ClipboardCheck, title: "Finalize sua compra" }, { icon: Download, title: "Receba o acesso imediatamente" }, { icon: Laptop, title: "Comece no celular, tablet ou computador" }];
  return <section className="bg-background py-20 sm:py-28"><Container><SectionHeading title="Como você recebe o material?" />
    <div className="relative grid gap-5 md:grid-cols-3">{steps.map(({ icon: Icon, title }, i) => <article key={title} className="step-card"><span className="font-display text-5xl font-black text-accent-strong/45">0{i + 1}</span><div className="icon-box mt-6"><Icon className="h-7 w-7" /></div><h3 className="mt-5 font-display text-lg font-extrabold text-primary">{title}</h3></article>)}</div>
    <div className="mt-10 flex justify-center"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div>
  </Container></section>;
}

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return <section className="bg-background py-20 sm:py-28"><Container><SectionHeading title="Perguntas Frequentes" />
    <div className="mx-auto max-w-3xl divide-y divide-border border-y border-border">{faqs.map(([question, answer], i) => <div key={question} className="faq-item"><button type="button" className="faq-trigger" onClick={() => setOpen(open === i ? null : i)} aria-expanded={open === i}><span>{question}</span><ChevronDown className={`h-5 w-5 shrink-0 transition-transform ${open === i ? "rotate-180" : ""}`} /></button><div className={`faq-answer ${open === i ? "faq-answer-open" : ""}`}><p>{answer}</p></div></div>)}</div>
  </Container></section>;
}

export function FinalCTA() {
  return <section data-sticky-suppress className="section-dark py-20 sm:py-28"><Container><div className="final-offer mx-auto max-w-4xl text-center"><span className="inline-flex items-center gap-2 text-xs font-extrabold uppercase tracking-widest text-accent-strong"><GraduationCap className="h-5 w-5" /> Seu espanhol começa aqui</span><h2 className="mt-5 font-display text-3xl font-black leading-tight text-primary-foreground sm:text-5xl">Garanta seu acesso agora pelo menor valor</h2><p className="mx-auto mt-5 max-w-2xl text-lg leading-relaxed text-on-dark-muted">Tenha uma biblioteca completa de mapas mentais para acompanhar você do nível A1 ao avançado.</p><div className="mt-7"><p className="text-sm text-on-dark-muted">Plano completo por apenas</p><p className="font-display text-5xl font-black text-primary-foreground"><span className="text-xl">R$</span> 19,90</p></div><div className="mt-8 flex justify-center"><PrimaryCTA>Quero meu acesso agora</PrimaryCTA></div><div className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm font-semibold text-primary-foreground">{["Pagamento único", "Acesso imediato", "Garantia de 7 dias"].map((item) => <span key={item} className="flex items-center gap-1.5"><Check className="h-4 w-4 text-success-bright" />{item}</span>)}</div></div></Container></section>;
}

const studentAvatars = [aluno1, aluno2, aluno3, aluno4, aluno5, aluno6];


export function Footer() {
  return <footer className="bg-footer py-12 text-footer-foreground"><Container><div className="flex flex-col items-center justify-between gap-7 border-b border-primary-foreground/10 pb-8 md:flex-row"><Logo inverse /><nav className="flex flex-wrap justify-center gap-5 text-sm text-on-dark-muted"><a href="#termos">Termos de Uso</a><a href="#privacidade">Política de Privacidade</a><a href="mailto:contato@espanholnomapa.com.br">Contato</a></nav></div><div className="pt-7 text-center text-xs leading-relaxed text-on-dark-muted md:text-left"><p>© 2026 Espanhol no Mapa. Todos os direitos reservados.</p><p className="mt-2 font-semibold text-footer-foreground">CNPJ: 24.212.419/0001-75</p><p className="mt-2 opacity-70">Produto educacional independente. Resultados dependem da dedicação e prática individual de cada aluno.</p></div></Container></footer>;
}



function ProductNotice() {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    let hideTimer = 0;
    const show = () => {
      setVisible(true);
      hideTimer = window.setTimeout(() => setVisible(false), 6000);
    };
    const first = window.setTimeout(show, 8000);
    const interval = window.setInterval(() => {
      setIndex((current) => (current + 1) % noticeNames.length);
      show();
    }, 45000);
    if (reduceMotion) return () => { window.clearTimeout(first); window.clearInterval(interval); window.clearTimeout(hideTimer); };
    return () => { window.clearTimeout(first); window.clearInterval(interval); window.clearTimeout(hideTimer); };
  }, []);
  return <aside className={`product-notice ${visible ? "product-notice-visible" : ""}`} aria-live="polite" aria-hidden={!visible}><img src={heroProductMobileAsset} alt="" width={56} height={56} /><div><div className="product-notice-name"><strong>{noticeNames[index]}</strong><span><CheckCircle2 className="h-3.5 w-3.5" /> Verificado</span></div><p>adquiriu o Kit!</p></div></aside>;
}

function MobileStickyCTA({ hidden }: { hidden: boolean }) {
  const [visible, setVisible] = useState(false);
  const dismissedRef = useRef(false);
  useEffect(() => {
    const update = () => {
      const heroCTA = document.querySelector<HTMLElement>("[data-primary-cta]");
      const suppressors = Array.from(document.querySelectorAll<HTMLElement>("[data-sticky-suppress]"));
      const passedHeroCTA = heroCTA ? heroCTA.getBoundingClientRect().bottom < 0 : window.scrollY > 600;
      const nearImportantCTA = suppressors.some((element) => {
        const rect = element.getBoundingClientRect();
        return rect.top < window.innerHeight && rect.bottom > 0;
      });
      setVisible(!dismissedRef.current && passedHeroCTA && !nearImportantCTA);
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);
  return <div className={`mobile-sticky-cta ${visible && !hidden ? "mobile-sticky-cta-visible" : ""}`} aria-hidden={!visible || hidden}>
    <a href="#planos" tabIndex={visible && !hidden ? 0 : -1} onClick={() => { dismissedRef.current = true; setVisible(false); }}>Quero meu acesso agora <ArrowRight className="h-5 w-5 shrink-0" /></a>
  </div>;
}

export function UpsellModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const closeRef = useRef<HTMLButtonElement>(null);
  useEffect(() => { if (!open) return; document.body.style.overflow = "hidden"; closeRef.current?.focus(); const key = (e: KeyboardEvent) => e.key === "Escape" && onClose(); window.addEventListener("keydown", key); return () => { document.body.style.overflow = ""; window.removeEventListener("keydown", key); }; }, [open, onClose]);
  if (!open) return null;
  const go = (url: string) => { if (url) window.location.href = withTracking(url); };
  return <div className="modal-backdrop" role="presentation" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}><div className="upsell-modal" role="dialog" aria-modal="true" aria-labelledby="upsell-title"><button ref={closeRef} type="button" onClick={onClose} className="modal-close" aria-label="Fechar oferta"><X className="h-5 w-5" /></button><div className="upsell-badge">Oferta exclusiva desta página</div><h2 id="upsell-title" className="mt-5 font-display text-2xl font-black uppercase leading-tight text-primary sm:text-3xl">Espere! Temos uma oferta especial para você</h2><p className="mt-3 text-lg font-extrabold text-primary">Leve o Plano Completo por apenas R$ 12,90</p><p className="mx-auto mt-3 max-w-lg text-sm leading-relaxed text-muted-foreground">Por apenas R$ 3 a mais, você desbloqueia toda a biblioteca completa de Espanhol.</p><div className="my-6 rounded-lg bg-cream p-5"><p className="text-sm font-bold text-price-old line-through">R$ 19,90</p><p className="font-display text-5xl font-black text-primary"><span className="text-lg">R$</span> 12,90</p><p className="mt-2 text-xs font-bold text-success">Você paga só R$ 3 a mais e desbloqueia o kit completo.</p></div><div className="grid gap-2 text-left sm:grid-cols-2">{["+300 mapas mentais", "Do A1 ao C2", "Todo o Essencial", "Mapas avançados", "6 bônus especiais", "Acesso vitalício"].map((item) => <div key={item} className="flex items-center gap-2 text-sm font-semibold"><CheckCircle2 className="h-4 w-4 shrink-0 text-success" />{item}</div>)}</div><button type="button" onClick={() => go(UPSELL_CHECKOUT_URL)} className="pricing-solid mt-7 w-full">Quero meu acesso agora <ArrowRight className="h-5 w-5" /></button><button type="button" onClick={() => go(ESSENCIAL_CHECKOUT_URL)} className="mt-4 text-xs font-semibold text-muted-foreground underline underline-offset-4 hover:text-primary">Não, quero só o Essencial por R$ 9,90</button></div></div>;
}

export function SalesPage() {
  const [modalOpen, setModalOpen] = useState(false);
  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduceMotion) return;
    document.documentElement.classList.add("reveal-ready");
    const items = Array.from(document.querySelectorAll<HTMLElement>("main section h2, .feature-card, .bonus-card, .pricing-card, .step-card"));
    items.forEach((item, index) => item.style.setProperty("--reveal-delay", `${(index % 3) * 65}ms`));
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => { if (entry.isIntersecting) { entry.target.classList.add("is-revealed"); observer.unobserve(entry.target); } });
    }, { threshold: 0.08, rootMargin: "0px 0px -40px" });
    items.forEach((item) => observer.observe(item));
    return () => { observer.disconnect(); document.documentElement.classList.remove("reveal-ready"); };
  }, []);
  return <><OfferBar /><main><Hero /><ProductPreview /><Testimonials /><Audience /><Bonuses /><Pricing onEssential={() => setModalOpen(true)} /><Guarantee /><AccessSteps /><FAQ /><FinalCTA /></main><Footer /><ProductNotice /><MobileStickyCTA hidden={modalOpen} /><UpsellModal open={modalOpen} onClose={() => setModalOpen(false)} /></>;
}
