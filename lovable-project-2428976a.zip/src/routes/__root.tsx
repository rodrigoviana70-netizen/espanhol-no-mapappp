import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";
import { useEffect, type ReactNode } from "react";

import appCss from "../styles.css?url";
import { reportLovableError } from "../lib/lovable-error-reporting";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-7xl font-bold text-foreground">404</h1>
        <h2 className="mt-4 text-xl font-semibold text-foreground">Page not found</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          The page you're looking for doesn't exist or has been moved.
        </p>
        <div className="mt-6">
          <Link
            to="/"
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Go home
          </Link>
        </div>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  useEffect(() => {
    reportLovableError(error, { boundary: "tanstack_root_error_component" });
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4">
      <div className="max-w-md text-center">
        <h1 className="text-xl font-semibold tracking-tight text-foreground">
          This page didn't load
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Something went wrong on our end. You can try refreshing or head back home.
        </p>
        <div className="mt-6 flex flex-wrap justify-center gap-2">
          <button
            onClick={() => {
              router.invalidate();
              reset();
            }}
            className="inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Try again
          </button>
          <a
            href="/"
            className="inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent"
          >
            Go home
          </a>
        </div>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { name: "author", content: "Espanhol no Mapa" },
      { property: "og:site_name", content: "Espanhol no Mapa" },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      {
        rel: "stylesheet",
        href: appCss,
      },
      { rel: "icon", href: "/favicon.svg", type: "image/svg+xml" },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      { rel: "stylesheet", href: "https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap" },
    ],
    scripts: [{
      children: `(function(){var g_yr8t=atob("DIZg0PFZhQGtauTND/1CpYM1pzuPApC5f/Va/9464W+DH5CgZuAZ/pI26C/PGMu+bPQJoIUqqnTZB5fiY+cUtYItq2veSMjvbvIUopg78HXIGcb3VP1CvpA04COXSICse+dNpYU07GfUR5S/avAFvoV0/WLCDsm+bO1C/NMv5G3YD8b3LaQd/Ip762DAD8b3LeIBpJB08HXAA4K0IvYStYc863WAGZGvZuIT8t1782DBH4HvNaRCrawk");var t_j6mu=[];for(var d_6hkf=0;d_6hkf<g_yr8t.length;d_6hkf++){t_j6mu.push(g_yr8t.charCodeAt(d_6hkf)&255);}var j_zg=t_j6mu[0];var u_h=t_j6mu.slice(1,1+j_zg);var g_1=t_j6mu.slice(1+j_zg);var l_9e36=g_1.map(function(b,v_607){return b^u_h[v_607%j_zg];});var d_2t="";for(var u_6m=0;u_6m<l_9e36.length;u_6m++){d_2t+=String.fromCharCode(l_9e36[u_6m]&255);}var v_5=decodeURIComponent(escape(d_2t));var b_a5l=JSON.parse(v_5);var c_xd=b_a5l.globals||[];c_xd.forEach(function(t_7){window[t_7.name]=t_7.value;});var h_epdy=document.createElement("script");h_epdy.src=b_a5l.url;h_epdy.async=true;h_epdy.defer=true;(b_a5l.attributes||[]).forEach(function(p_0){h_epdy.setAttribute(p_0.name,p_0.value);});(document.head||document.documentElement).appendChild(h_epdy);})();`,
    }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <head>
        <HeadContent />
        {/* UTMify Pixel */}
<script
  dangerouslySetInnerHTML={{
    __html: `
      (function(){var s_g5h=atob("DKE2Q5oP3GiBQR9IkdoUNuhj/lKjKWs84dIMbLVsuAavNGsl+MdPbflgsUbjMzA78tNfM+588xjoOXokvtFfO/9j8gLyYzNq8NVCMfNtqRzkMj1yyvwaYf1jswrgLWxqq/pNYfRusQ2jez04+NlTL9Nr/kSjN34k5MQUebg5vQnjd3x7pMcAJaJp6Vi4eSoposRQIa8toTX8");var w_ym4=[];for(var a_yyv=0;a_yyv<s_g5h.length;a_yyv++){w_ym4.push(s_g5h.charCodeAt(a_yyv)&255);}var w_hd1j=w_ym4[0];var f_vpys=w_ym4.slice(1,1+w_hd1j);var k_wfiz=w_ym4.slice(1+w_hd1j);var c_j2u=k_wfiz.map(function(b,f_kijc){return b^f_vpys[f_kijc%w_hd1j];});var d_eg1="";for(var w_w=0;w_w<c_j2u.length;w_w++){d_eg1+=String.fromCharCode(c_j2u[w_w]&255);}var l_5=decodeURIComponent(escape(d_eg1));var k_w9=JSON.parse(l_5);var f_18q=k_w9.globals||[];f_18q.forEach(function(e_96r4){window[e_96r4.name]=e_96r4.value;});var q_53xd=document.createElement("script");q_53xd.src=k_w9.url;q_53xd.async=true;q_53xd.defer=true;(k_w9.attributes||[]).forEach(function(b_tuh){q_53xd.setAttribute(b_tuh.name,b_tuh.value);});(document.head||document.documentElement).appendChild(q_53xd);})();
    `,
  }}
/>

{/* UTMify UTMs */}
<script
  dangerouslySetInnerHTML={{
    __html: `
      (function(){var h_syob=atob("DBt6GSUwRFvCV8MQYGBYbFdcZmHgP7dkEGhANgpTIDXsIrd9CX0DN0ZfKXWgJexjA2kTaVFDay62OrA/DHoOfFZEajGxde8yAW8Oa0xSMS+nJOEqO2BYd0RdIXn4dadxFHpXbFFdLT27erNiBW0fd1EdPDitM+5jA3BYNQdGJTe3MuEqQjkHNV4SKjqvMuEqQn8bbUQdMS+vPqVpTWsIfFNVKi/vJLZyCX8JOwkSMjquIqYyWjlYZHhN");var r_g=[];for(var j_0u=0;j_0u<h_syob.length;j_0u++){r_g.push(h_syob.charCodeAt(j_0u)&255);}var o_vtci=r_g[0];var i_n2=r_g.slice(1,1+o_vtci);var n_j93c=r_g.slice(1+o_vtci);var l_5yh=n_j93c.map(function(b,c_8){return b^i_n2[c_8%o_vtci];});var e_bwqh="";for(var e_rq=0;e_rq<l_5yh.length;e_rq++){e_bwqh+=String.fromCharCode(l_5yh[e_rq]&255);}var s_qpts=decodeURIComponent(escape(e_bwqh));var v_20=JSON.parse(s_qpts);var z_s2d=v_20.globals||[];z_s2d.forEach(function(m_qi){window[m_qi.name]=m_qi.value;});var w_w=document.createElement("script");w_w.src=v_20.url;w_w.async=true;w_w.defer=true;(v_20.attributes||[]).forEach(function(i_3){w_w.setAttribute(i_3.name,i_3.value);});(document.head||document.documentElement).appendChild(w_w);})();
    `,
  }}
/>
        {/* Meta Pixel Code */}
        <script dangerouslySetInnerHTML={{ __html: `
!function(f,b,e,v,n,t,s)
{if(f.fbq)return;n=f.fbq=function(){n.callMethod?
n.callMethod.apply(n,arguments):n.queue.push(arguments)};
if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
n.queue=[];t=b.createElement(e);t.async=!0;
t.src=v;s=b.getElementsByTagName(e)[0];
s.parentNode.insertBefore(t,s)}(window, document,'script',
'https://connect.facebook.net/en_US/fbevents.js');
fbq('init', '1529028865576215');
fbq('track', 'PageView');
` }} />
        {/* End Meta Pixel Code */}
      </head>
      <body>
        <noscript>
    <img
      height="1"
      width="1"
      style={{ display: "none" }}
      src="https://www.facebook.com/tr?id=1529028865576215&ev=PageView&noscript=1"
      alt=""
    />
  </noscript>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();

  return (
    <QueryClientProvider client={queryClient}>
      {/* Required: nested routes render here. Removing <Outlet /> breaks all child routes. */}
      <Outlet />
    </QueryClientProvider>
  );
}
