import { createFileRoute } from "@tanstack/react-router";
import { SalesPage } from "@/components/sales-page";
import heroMobileAsset from "@/assets/hero-guia-720.avif";
import heroDesktopAsset from "@/assets/hero-guia-1200.avif";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Espanhol no Mapa | Espanhol com Mapas Mentais" },
      { name: "description", content: "Aprenda espanhol do básico ao avançado com mapas mentais visuais, exercícios e materiais organizados. Acesso imediato e vitalício." },
      { property: "og:title", content: "Espanhol no Mapa | Aprenda com Mapas Mentais" },
      { property: "og:description", content: "Uma biblioteca visual completa para aprender espanhol do A1 ao C2, no seu ritmo." },
      { property: "og:type", content: "website" },
      { property: "og:url", content: "/" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
    links: [
      { rel: "canonical", href: "/" },
      { rel: "preload", as: "image", href: heroMobileAsset, fetchPriority: "high", media: "(max-width: 767px)" },
      { rel: "preload", as: "image", href: heroDesktopAsset, fetchPriority: "high", media: "(min-width: 768px)" },
    ],
    scripts: [{
      type: "application/ld+json",
      children: JSON.stringify({
        "@context": "https://schema.org",
        "@type": "Product",
        name: "Espanhol no Mapa",
        description: "Biblioteca visual com mais de 300 mapas mentais de espanhol, do nível A1 ao C2.",
        brand: { "@type": "Brand", name: "Espanhol no Mapa" },
        offers: { "@type": "Offer", priceCurrency: "BRL", price: "19.90", availability: "https://schema.org/InStock" },
      }),
    }],
  }),
  component: SalesPage,
});
